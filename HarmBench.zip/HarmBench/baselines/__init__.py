# baselines
import importlib

_method_mapping = {
    "DirectRequest": "baselines.direct_request",
}

def get_method_class(method):
    """
    Returns the method class given the method name. This is used to access static methods.
    """
    if method not in _method_mapping:
        raise ValueError(f"Can not find method {method}")
    module_path = _method_mapping[method]
    module = importlib.import_module(module_path)
    method_class = getattr(module, method)  # Class name assumed to be the same as method name
    return method_class

def init_method(method_class, method_config):
    output = method_class(**method_config)
    return output

